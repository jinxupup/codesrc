package com.jjb.acl.web;

public class MainEncry {

	public static void main(String[] args) {
	}
}
