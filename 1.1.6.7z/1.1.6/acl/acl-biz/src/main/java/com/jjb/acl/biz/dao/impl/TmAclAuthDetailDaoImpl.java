package com.jjb.acl.biz.dao.impl;

import org.springframework.stereotype.Repository;

import com.jjb.acl.biz.dao.TmAclAuthDetailDao;
import com.jjb.acl.infrastructure.TmAclAuthDetail;
import com.jjb.unicorn.base.dao.impl.AbstractBaseDao;

/**
 * 
 * @ClassName TmAclAuthDetailDaoImpl
 * @Description TODO(这里用一句话描述这个类的作用)
 * @author H.N
 * @Date 2017年12月2日 下午3:02:14
 * @version 1.0.0
 */
@Repository("tmAclAuthDetailDao")
public class TmAclAuthDetailDaoImpl extends AbstractBaseDao<TmAclAuthDetail> implements TmAclAuthDetailDao {

	
	
}
