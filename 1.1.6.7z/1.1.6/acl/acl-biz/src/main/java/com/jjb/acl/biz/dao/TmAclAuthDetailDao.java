package com.jjb.acl.biz.dao;

import com.jjb.acl.infrastructure.TmAclAuthDetail;
import com.jjb.unicorn.base.dao.BaseDao;

/**
 * 
 * @ClassName TmAclAuthDetailDao
 * @Description TODO(这里用一句话描述这个类的作用)
 * @author H.N
 * @Date 2017年12月2日 下午3:01:08
 * @version 1.0.0
 */
public interface TmAclAuthDetailDao extends BaseDao<TmAclAuthDetail>{


}
