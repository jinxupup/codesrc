package com.jjb.acl.facility.enums.bus;


/**
 * 性别
 * @author Big.R
 *
 */
public enum Gender {

	/**
	 *	男
	 */
	M,
	/**
	 *	女 
	 */
	F
}
