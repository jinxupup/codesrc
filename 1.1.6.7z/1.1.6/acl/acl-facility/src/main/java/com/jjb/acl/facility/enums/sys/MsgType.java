package com.jjb.acl.facility.enums.sys;

public enum MsgType {
	
	CreditLife("信用生活");
	
	public String msgDesc;
	
	private MsgType(String msgDesc) {
		
		this.msgDesc=msgDesc;
	}

}
