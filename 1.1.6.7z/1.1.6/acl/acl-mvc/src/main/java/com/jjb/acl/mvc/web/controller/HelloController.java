package com.jjb.acl.mvc.web.controller;

public class HelloController {
//
//	@SuppressWarnings("deprecation")
//	public HelloController() {
//		setCommandClass(TmAclDict.class);
//		setCommandName("tmAclDict");
//	}
//
//	@Override
//	protected ModelAndView handle(HttpServletRequest request,
//			HttpServletResponse response, Object command, BindException errors)
//			throws Exception {
//
//		ModelAndView modelAndView = new ModelAndView("hello.ftl");
//		modelAndView.addObject("tmAclDict");
//
//
//		b(request);
//
//		return modelAndView;
//	}
//
//	@SuppressWarnings("deprecation")
//	@Override
//	protected void initBinder(HttpServletRequest request,
//			ServletRequestDataBinder binder) throws Exception {
//		// TODO Auto-generated method stub
//		super.initBinder(request, binder);
//
//
//		binder.bind(request);
////		binder.registerCustomEditor(requiredType, propertyEditor);
//
//
//
//
//
////		ServletRequestDataBinder s = new ServletRequestDataBinder(s);
//
//	}
//
//	private Object b(HttpServletRequest request){
//
//		TmAclDict a = BeanUtils.instantiateClass(TmAclDict.class);
//
//		ServletRequestDataBinder binder = new ServletRequestDataBinder(a);
//
//
////		binder.registerCustomEditor(Date.class, new UnicornDateEditor());
//
//	 	binder.bind(request);
//		TmAclDict t = (TmAclDict) binder.getTarget();
//
//		return binder.getTarget();
//	}
//
//

}
